## ---- include = FALSE---------------------------------------------------------
knitr::opts_chunk$set(
  collapse = TRUE,
  comment = "#>"
)

## ----setup--------------------------------------------------------------------
library(blblm)
library(tidyverse)

## ----eval = FALSE-------------------------------------------------------------
#  #' @param data The input data
#  read_list <- function(data) {
#    pattern = paste0(data, collapse = "|") # Translating name into the regExpress
#    # Read all files under working directory at once
#    files <- list.files(path = getwd(), pattern = pattern, full.names = T) %>%
#      map_df(~fread(.))
#    files # Returning the file
#  }

## -----------------------------------------------------------------------------
split_data <- function(data, m) {
  idx <- sample.int(m, nrow(data), replace = TRUE)
  data %>% split(idx)
}
split_data(mtcars,m = 10) %>% # Split the data randomly into 10 subsample
  head()

## ----eval = FALSE-------------------------------------------------------------
#  # Non-parallel version lm
#  blblm <- function(formula, data, m = 10, B = 5000) {
#    if(typeof(data) == "character"){
#      df <- read_list(data)
#      data_list <- split_data(df, m)
#    }
#    else{
#      data_list <- split_data(data, m)
#    }
#    estimates <- map(
#      data_list,
#      ~ lm_each_subsample(formula = formula, data = ., n = nrow(data), B = B))
#    res <- list(estimates = estimates, formula = formula)
#    class(res) <- "blblm"
#    invisible(res)
#  }

## ----eval = FALSE-------------------------------------------------------------
#  # Parallel version of rlm
#  blblm_robust_parallel <- function(formula, data, m = 10, B = 5000, core = 1) {
#    cl <- makeCluster(core)
#    clusterExport(cl, c("lm_robust_each_boot","lm1_robust","blbcoef","blbsigma"))
#    if(typeof(data) == "character"){
#      df <- read_list(data)
#      data_list <- split_data(df, m)
#    }
#    else{
#      data_list <- split_data(data, m)
#    }
#    estimates <- parLapplyLB(cl,
#                             data_list,
#                             chunk.size = 2,
#                             lm_robust_each_subsample,formula = formula, n = nrow(data), B = B)
#    stopCluster(cl)
#    res <- list(estimates = estimates, formula = formula)
#    class(res) <- "blblm"
#    invisible(res)
#  }
#  
#  blblm_furrr <- function(formula, data, m = 10, B = 5000, core = 1) {
#    future::plan(future::multiprocess, workers = core)
#    if(typeof(data) == "character"){
#      df <- read_list(data)
#      data_list <- split_data(df, m)
#    }
#    else{
#      data_list <- split_data(data, m)
#    }
#    estimates <- future_map(
#      data_list,
#      ~ lm_each_subsample(formula = formula, data = ., n = nrow(data), B = B))
#    res <- list(estimates = estimates, formula = formula)
#    class(res) <- "blblm"
#    invisible(res)
#    closeAllConnections()
#  }

## ----eval = FALSE-------------------------------------------------------------
#  lm_each_subsample <- function(formula, data, n, B) {
#    replicate(B, lm_each_boot(formula, data, n), simplify = FALSE)
#  }

## ----eval = FALSE-------------------------------------------------------------
#  lm_each_boot <- function(formula, data, n) {
#    freqs <- rmultinom(1, n, rep(1, nrow(data)))
#    lm1(formula, data, freqs)
#  }
#  
#  lm1 <- function(formula, data, freqs) {
#    # drop the original closure of formula,
#    # otherwise the formula will pick a wront variable from the global scope.
#    environment(formula) <- environment()
#    fit <- lm(formula, data, weights = freqs)
#    list(coef = blbcoef(fit), sigma = blbsigma(fit))
#  }

## ----eval = FALSE-------------------------------------------------------------
#  lm_robust_each_subsample <- function(formula, data, n, B) {
#    replicate(B, lm_each_boot(formula, data, n), simplify = FALSE)
#  }
#  
#  lm_robust_each_boot <- function(formula, data, n) {
#    freqs <- rmultinom(1, n, rep(1, nrow(data)))
#    lm1(formula, data, freqs)
#  }
#  
#  lm1_robust <- function(formula, data, freqs) {
#    # drop the original closure of formula,
#    # otherwise the formula will pick a wront variable from the global scope.
#    environment(formula) <- environment()
#    fit <- rlm(formula, data, weights = freqs)
#    list(coef = blbcoef(fit), sigma = blbsigma(fit))
#  }

## ----eval = FALSE-------------------------------------------------------------
#  blbglm_prallel <- function(formula, data, family = 'gaussian', m = 10, B = 5000, core = 1) {
#    cl <- makeCluster(core)
#    clusterExport(cl, c("glm_each_boot","glm_base","blbcoef","blbsigma"))
#    if(typeof(data) == "character"){
#      df <- read_list(data)
#      data_list <- split_data(df, m)
#    }
#    else{
#      data_list <- split_data(data, m)
#    }
#    estimates <- parLapplyLB(cl,
#                             data_list,
#                             chunk.size = 2,
#                             glm_each_subsample,formula = formula, family = family, n = nrow(data), B = B)
#    stopCluster(cl)
#    res <- list(estimates = estimates, formula = formula)
#    class(res) <- "blblm"
#    invisible(res)
#  }
#  # Bottom level
#  glm_base <- function(formula, family, data, freqs) {
#    # drop the original closure of formula,
#    # otherwise the formula will pick a wront variable from the global scope.
#    environment(formula) <- environment()
#    fit <- glm(formula, family = family, data, weights = freqs)
#    list(coef = blbcoef(fit), sigma = blbsigma(fit))
#   }

## ----eval = FALSE-------------------------------------------------------------
#  mean_lwr_upr <- function(x, level = 0.95) {
#    alpha <- 1 - level
#    c(fit = mean(x), quantile(x, c(alpha / 2, 1 - alpha / 2)) %>% set_names(c("lwr", "upr")))
#  }
#  
#  map_mean <- function(.x, .f, ...) {
#    (map(.x, .f, ...) %>% reduce(`+`)) / length(.x)
#  }
#  
#  map_cbind <- function(.x, .f, ...) {
#    map(.x, .f, ...) %>% reduce(cbind)
#  }
#  
#  map_rbind <- function(.x, .f, ...) {
#    map(.x, .f, ...) %>% reduce(rbind)
#  }

## ----eval = FALSE-------------------------------------------------------------
#  sigma.blblm <- function(object, confidence = FALSE, level = 0.95, ...) {
#    est <- object$estimates
#    sigma <- mean(map_dbl(est, ~ mean(map_dbl(., "sigma"))))
#    if (confidence) {
#      alpha <- 1 - 0.95
#      limits <- est %>%
#        map_mean(~ quantile(map_dbl(., "sigma"), c(alpha / 2, 1 - alpha / 2))) %>%
#        set_names(NULL)
#      return(c(sigma = sigma, lwr = limits[1], upr = limits[2]))
#    } else {
#      return(sigma)
#    }
#  }
#  
#  coef.blblm <- function(object, ...) {
#    est <- object$estimates
#    map_mean(est, ~ map_cbind(., "coef") %>% rowMeans())
#  }
#  
#  confint.blblm <- function(object, parm = NULL, level = 0.95, ...) {
#    if (is.null(parm)) {
#      parm <- attr(terms(fit$formula), "term.labels")
#    }
#    alpha <- 1 - level
#    est <- object$estimates
#    out <- map_rbind(parm, function(p) {
#      map_mean(est, ~ map_dbl(., list("coef", p)) %>% quantile(c(alpha / 2, 1 - alpha / 2)))
#    })
#    if (is.vector(out)) {
#      out <- as.matrix(t(out))
#    }
#    dimnames(out)[[1]] <- parm
#    out
#  }

## ----eval = FALSE-------------------------------------------------------------
#  predict.blblm <- function(object, new_data, confidence = FALSE, level = 0.95,core = 1, ...) {
#    est <- object$estimates
#    X <- model.matrix(reformulate(attr(terms(object$formula), "term.labels")), new_data)
#    if (confidence) {
#      map_mean_parallel(est, ~ map_cbind(., ~ X %*% .$coef) %>%
#        apply(1, mean_lwr_upr, level = level) %>%
#        t())
#    } else {
#      map_mean(est, ~ map_cbind(., ~ X %*% .$coef) %>% rowMeans())
#    }
#  }

## ----warning=FALSE------------------------------------------------------------
fit <- blblm(mpg ~ wt * hp, data = mtcars, m = 3, B = 100)
coef(fit)

## -----------------------------------------------------------------------------
confint(fit, c("wt", "hp"))

## -----------------------------------------------------------------------------
sigma(fit)
sigma(fit, confidence = TRUE)

